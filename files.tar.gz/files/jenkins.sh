echo ##########################
echo Installing Jenkins
echo ##########################

wget -q -O - https://pkg.jenkins.io/debian/jenkins-ci.org.key | sudo apt-key add -
echo deb http://pkg.jenkins.io/debian-stable binary/ | sudo tee /etc/apt/sources.list.d/jenkins.list
sudo apt-get -y update
sudo apt-get install -y jenkins
sudo apt-get install -y default-jre default-jdk
echo installing maven
sudo apt-get install -y maven


apt-get install -y docker-compose apache2-utils curl docker.io
mkdir /docker-registry
mkdir  /docker-registry/data
mkdir /docker-registry/nginx
chown -R root:root /docker-registry

echo "nginx:
  image: "nginx:1.9"
  ports:
    - 443:443
    - 80:80
  links:
    - registry:registry
  volumes:
    - /docker-registry/nginx/:/etc/nginx/conf.d
registry:
  image: registry:2
  ports:
    - 127.0.0.1:5000:5000
  environment:
    REGISTRY_STORAGE_FILESYSTEM_ROOTDIRECTORY: /data
  volumes:
    - /docker-registry/data:/data" > /docker-registry/docker-compose.yml
	


echo "[Unit]
Description=Starting docker registry

[Service]
Environment= MY_ENVIRONMENT_VAR = /docker-registry/docker-compose.yml
WorkingDirectory=/docker-registry
ExecStart=/usr/bin/docker-compose up
Restart=always

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/docker-registry.service


service docker-registry restart

docker ps

cp /home/ubuntu/files/registry.conf /docker-registry/nginx/
cp /home/ubuntu/files/registry.password /docker-registry/nginx/


cd /docker-registry
docker-compose up &
chown -R root:root /docker-registry
systemctl daemon-reload

service docker-registry restart
systemctl daemon-reload
service docker-registry restart




